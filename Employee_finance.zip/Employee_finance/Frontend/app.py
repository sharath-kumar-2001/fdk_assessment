import streamlit as st
import requests

# ========================
# CONFIG
# ========================
BACKEND_URL = "http://127.0.0.1:8000"  # FastAPI server URL

# ========================
# SESSION STATE
# ========================
if "token" not in st.session_state:
    st.session_state.token = None
if "role" not in st.session_state:
    st.session_state.role = None
if "user" not in st.session_state:
    st.session_state.user = None


# ========================
# LOGIN PAGE
# ========================
def login_page():
    st.title("💼 Employee Expense Management")
    st.subheader("Login")

    email = st.text_input("Email")
    password = st.text_input("Password", type="password")

    if st.button("Login"):
        try:
            res = requests.post(
                f"{BACKEND_URL}/auth/login",
                data={"username": email, "password": password},
                headers={"accept": "application/json"},
            )
            if res.status_code == 200:
                data = res.json()
                st.session_state.token = data["access_token"]
                st.success("✅ Login successful!")
                st.rerun()
            else:
                st.error("❌ Invalid email or password.")
        except Exception as e:
            st.error(f"Error connecting to backend: {e}")


# ========================
# EMPLOYEE DASHBOARD
# ========================
def employee_dashboard():
    st.title("👤 Employee Dashboard")
    st.sidebar.header("Employee Menu")
    choice = st.sidebar.radio("Select Page", ["Submit Expense", "My Expenses", "Logout"])

    headers = {"Authorization": f"Bearer {st.session_state.token}"}

    if choice == "Submit Expense":
        st.subheader("🧾 Submit New Expense")

        amount = st.number_input("Amount (₹)", min_value=0.0, step=100.0)
        description = st.text_area("Description")
        receipt_url = st.text_input("Receipt URL (optional)")

        if st.button("Submit Expense"):
            payload = {
                "amount": amount,
                "description": description,
                "receipt_url": receipt_url,
            }
            res = requests.post(f"{BACKEND_URL}/expenses/submit", json=payload, headers=headers)
            if res.status_code == 200:
                st.success("✅ Expense submitted successfully!")
            else:
                st.error(f"❌ {res.json().get('detail', 'Submission failed.')}")

    elif choice == "My Expenses":
        st.subheader("📊 My Submitted Expenses")
        res = requests.get(f"{BACKEND_URL}/expenses/my", headers=headers)
        if res.status_code == 200:
            data = res.json()
            if not data:
                st.info("No expenses found.")
            else:
                for exp in data:
                    with st.expander(f"Expense #{exp['id']} - {exp['status']}"):
                        st.write(f"💰 Amount: ₹{exp['amount']}")
                        st.write(f"📝 Description: {exp['description']}")
                        st.write(f"📅 Date: {exp['created_at']}")
                        if exp.get("receipt_url"):
                            st.markdown(f"[📎 View Receipt]({exp['receipt_url']})")
        else:
            st.error("Failed to fetch expenses.")

    elif choice == "Logout":
        st.session_state.token = None
        st.rerun()


# ========================
# APPROVER DASHBOARD
# ========================
def approver_dashboard():
    st.title("🧑‍💼 Approver Dashboard")
    st.sidebar.header("Approver Menu")
    choice = st.sidebar.radio("Select Page", ["Pending Approvals", "Approved Expenses", "Logout"])

    headers = {"Authorization": f"Bearer {st.session_state.token}"}

    if choice == "Pending Approvals":
        st.subheader("🕓 Pending Approvals")
        res = requests.get(f"{BACKEND_URL}/approvals/pending", headers=headers)
        if res.status_code == 200:
            data = res.json()
            if not data:
                st.info("No pending approvals.")
            else:
                for exp in data:
                    with st.expander(f"Expense #{exp['id']} - {exp['description']}"):
                        st.write(f"💰 Amount: ₹{exp['amount']}")
                        st.write(f"Submitted by: {exp['employee_id']}")
                        st.write(f"Status: {exp['status']}")
                        col1, col2 = st.columns(2)
                        with col1:
                            if st.button(f"✅ Approve #{exp['id']}"):
                                res = requests.patch(f"{BACKEND_URL}/approvals/{exp['id']}/approve", headers=headers)
                                st.success("Approved ✅")
                                st.rerun()
                        with col2:
                            reason = st.text_input(f"Reason for rejection #{exp['id']}")
                            if st.button(f"❌ Reject #{exp['id']}"):
                                res = requests.patch(
                                    f"{BACKEND_URL}/approvals/{exp['id']}/reject",
                                    params={"reason": reason},
                                    headers=headers,
                                )
                                st.warning("Rejected ❌")
                                st.rerun()
        else:
            st.error("Failed to fetch pending approvals.")

    elif choice == "Approved Expenses":
        st.subheader("✅ Approved / Rejected Expenses")
        res = requests.get(f"{BACKEND_URL}/approvals/approved", headers=headers)
        if res.status_code == 200:
            for exp in res.json():
                st.write(f"#{exp['id']} | ₹{exp['amount']} | {exp['status']}")
        else:
            st.error("Could not fetch approved list.")

    elif choice == "Logout":
        st.session_state.token = None
        st.rerun()


# ========================
# ADMIN DASHBOARD
# ========================
def admin_dashboard():
    st.title("🧑‍💻 Admin Dashboard")
    st.sidebar.header("Admin Menu")
    choice = st.sidebar.radio("Select Page", ["View Workflows", "Create Workflow", "Logout"])

    headers = {"Authorization": f"Bearer {st.session_state.token}"}

    if choice == "View Workflows":
        st.subheader("📜 Existing Workflows")
        res = requests.get(f"{BACKEND_URL}/workflows/", headers=headers)
        if res.status_code == 200:
            workflows = res.json()
            if workflows:
                for wf in workflows:
                    st.write(f"📌 **{wf['job_title']}** → {wf['steps']}")
            else:
                st.info("No workflows found.")
        else:
            st.error("Failed to fetch workflows.")

    elif choice == "Create Workflow":
        st.subheader("➕ Create New Workflow")
        job_title = st.text_input("Job Title")
        steps = st.text_area("Steps (comma separated)")
        if st.button("Add Workflow"):
            payload = {"job_title": job_title, "steps": [s.strip() for s in steps.split(",")]}
            res = requests.post(f"{BACKEND_URL}/workflows/", json=payload, headers=headers)
            if res.status_code == 200:
                st.success("✅ Workflow created successfully!")
            else:
                st.error("Failed to create workflow.")

    elif choice == "Logout":
        st.session_state.token = None
        st.rerun()


# ========================
# MAIN ROUTER
# ========================
def main():
    st.set_page_config(page_title="Expense App", page_icon="💰", layout="centered")

    if not st.session_state.token:
        login_page()
    else:
        # Ideally, you'd decode JWT or use `/auth/me` to get the role.
        # For simplicity, let's let user choose their role manually here.
        role = st.sidebar.selectbox("Select Role", ["employee", "approver", "admin"])

        if role == "employee":
            employee_dashboard()
        elif role == "approver":
            approver_dashboard()
        elif role == "admin":
            admin_dashboard()
        else:
            st.error("Unknown role.")


if __name__ == "__main__":
    main()
