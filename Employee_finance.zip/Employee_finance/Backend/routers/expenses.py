from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from db_setup import get_db, Expense, ApprovalWorkflow, ApprovalStep, User, ExpenseStatus
from schemas import ExpenseCreate, ExpenseOut
from utils.auth_utils import get_current_user
from datetime import datetime

router = APIRouter(prefix="/expenses", tags=["Expenses"])

@router.post("/submit", response_model=ExpenseOut)
def submit_expense(
    expense: ExpenseCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    print("Role: ",current_user.role)
    if current_user.role != "employee":
        raise HTTPException(status_code=403, detail="Only employees can submit expenses")

    new_expense = Expense(
        employee_id=current_user.id,
        amount=expense.amount,
        description=expense.description,
        receipt_url=expense.receipt_url,
        status="SUBMITTED",
        created_at=datetime.utcnow(),
    )
    db.add(new_expense)
    db.commit()
    db.refresh(new_expense)

    workflow = db.query(ApprovalWorkflow).filter(
        ApprovalWorkflow.job_title == current_user.job_title
    ).first()

    if not workflow:
        raise HTTPException(status_code=400, detail="No workflow configured for your job title")

    for idx, approver_title in enumerate(workflow.steps):
        approvers = db.query(User).filter(User.job_title == approver_title).all()
        for approver in approvers:
            step_status = "pending" if idx == 0 else "waiting"
            db.add(
                ApprovalStep(
                    expense_id=new_expense.id,
                    approver_id=approver.id,
                    step_order=idx + 1,
                    status=step_status,
                    updated_at=datetime.utcnow(),
                )
            )

    db.commit()
    return new_expense

@router.get("/my", response_model=list[ExpenseOut])
def get_my_expenses(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    expenses = db.query(Expense).options(joinedload(Expense.approval_steps).joinedload(ApprovalStep.approver)).filter(Expense.employee_id == current_user.id).all()
    return expenses
