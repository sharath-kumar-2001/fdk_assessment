from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from db_setup import get_db, Expense, ApprovalStep, User
from utils.auth_utils import get_current_user
from datetime import datetime
from schemas import RejectionRequest, ExpenseOut

router = APIRouter(prefix="/approvals", tags=["Approvals"])

@router.get("/pending", response_model=list[ExpenseOut])
def pending_approvals(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if current_user.role == "admin":
            expenses = (
                db.query(Expense)
                .join(ApprovalStep, ApprovalStep.expense_id == Expense.id)
                .filter(ApprovalStep.status.in_(["pending", "waiting"]))
                .distinct()
                .all()
            )
    else:
        # For individual approver -> only expenses assigned to them and pending
        expenses = (
            db.query(Expense)
            .join(ApprovalStep, ApprovalStep.expense_id == Expense.id)
            .filter(
                ApprovalStep.approver_id == current_user.id,
                ApprovalStep.status == "pending"
            )
            .distinct()
            .all()
        )

    return expenses

@router.get("/approved", response_model=list[ExpenseOut])
def approved_approvals(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    
    expenses = (
        db.query(Expense)
        .join(ApprovalStep, ApprovalStep.expense_id == Expense.id)
        .filter(ApprovalStep.status.in_(["pending", "approved", "waiting", "rejected"]))
        .distinct()
        .all()
    )


    return expenses

@router.patch("/{step_id}/approve")
def approve_step(step_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    print(type(step_id))
    step = db.query(ApprovalStep).filter(ApprovalStep.id == step_id).first()
    print('step', step)
    if not step:
        raise HTTPException(status_code=404, detail="Step not found")

    if step.approver_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized for this step")

    step.status = "approved"
    step.updated_at = datetime.utcnow()
    db.commit()

    # Move next step to pending
    next_step = (
        db.query(ApprovalStep)
        .filter(
            ApprovalStep.expense_id == step.expense_id,
            ApprovalStep.step_order == step.step_order + 1,
        )
        .first()
    )
    if next_step:
        next_step.status = "pending"
        db.commit()
    else:
        # Final approval — mark expense as fully approved
        expense = db.query(Expense).filter(Expense.id == step.expense_id).first()
        expense.status = "approved"
        db.commit()

    return {"message": "Step approved"}

@router.patch("/{step_id}/reject")
def reject_expense(
    step_id: int,
    rejection: RejectionRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    step = db.query(ApprovalStep).filter(ApprovalStep.id == step_id).first()
    if not step:
        raise HTTPException(status_code=404, detail="Approval step not found")

    # if step.approver_id != current_user.id:
    #     raise HTTPException(status_code=403, detail="Not authorized to reject this expense")
    print("User: ", current_user.full_name)
    # Update step
    step.status = "rejected"
    step.rejection_reason = rejection.reason
    step.rejected_by = current_user.full_name
    step.updated_at = datetime.utcnow()

    # Update expense
    expense = db.query(Expense).filter(Expense.id == step.expense_id).first()
    expense.status = "rejected"
    # expense.rejection_reason = rejection.reason
    # expense.rejected_by = current_user.full_name

    db.commit()

    return {
        "message": "Expense rejected successfully",
        "rejected_by": current_user.full_name,
        "reason": rejection.reason
    }