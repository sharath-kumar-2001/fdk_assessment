from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from db_setup import get_db, ApprovalWorkflow, User
from schemas import WorkflowCreate, WorkflowOut
from utils.auth_utils import get_current_user
from datetime import datetime

router = APIRouter(prefix="/workflows", tags=["Workflows"])

@router.post("/", response_model=WorkflowOut)
def create_workflow(workflow: WorkflowCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Only admins can create workflows")

    existing = db.query(ApprovalWorkflow).filter(ApprovalWorkflow.job_title == workflow.job_title).first()
    if existing:
        raise HTTPException(status_code=400, detail="Workflow already exists for this job title")

    new_wf = ApprovalWorkflow(
        job_title=workflow.job_title,
        steps=workflow.steps,
        created_at=datetime.utcnow()
    )
    db.add(new_wf)
    db.commit()
    db.refresh(new_wf)
    return new_wf

@router.get("/", response_model=list[WorkflowOut])
def list_workflows(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Only admins can view workflows")
    return db.query(ApprovalWorkflow).all()
