import sqlite3

# Path to your SQLite database file
db_path = r"C:\Users\sharathkumar.v\OneDrive - Prodapt Solutions Private Limited\Documents\Employee_finance\Backend\expenses.db"  # change this if your file has a different name

# Connect to the database
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Show all tables
print("📋 Tables:")
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()
for table in tables:
    # print("-", table[0])

# View data in ApprovalStep table
    print(f"\n📊 Table name: {table[0]}")
    cursor.execute(f"SELECT * FROM {table[0]};")
    rows = cursor.fetchall()
    for row in rows:
        print(row)

conn.close()
