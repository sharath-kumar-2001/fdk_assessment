from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime

class UserBase(BaseModel):
    full_name: str
    email: EmailStr
    job_title: str

class UserCreate(UserBase):
    password: str
    role: str

class UserOut(UserBase):
    id: int
    role: str
    class Config:
        orm_mode = True

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class ExpenseBase(BaseModel):
    amount: float
    description: Optional[str] = None
    receipt_url: Optional[str] = None

class ExpenseCreate(ExpenseBase):
    pass

class ExpenseOut(ExpenseBase):
    id: int
    amount: float
    description: str
    status: str
    created_at: datetime
    class Config:
        orm_mode = True

class WorkflowCreate(BaseModel):
    job_title: str
    steps: List[str]

class WorkflowOut(WorkflowCreate):
    id: int
    created_at: datetime
    class Config:
        orm_mode = True

class RejectionRequest(BaseModel):
    reason: str