from sqlalchemy import create_engine, Column, Integer, String, Float, ForeignKey, DateTime, Enum, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import enum
import os


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_URL = f"sqlite:///{os.path.join(BASE_DIR, 'expenses.db')}"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

class UserRole(str, enum.Enum):
    EMPLOYEE = "employee"
    APPROVER = "approver"
    ADMIN = "admin"

class ExpenseStatus(str, enum.Enum):
    SUBMITTED = "submitted"
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"

class ApprovalStepStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(Enum(UserRole), nullable=False, default=UserRole.EMPLOYEE)
    job_title = Column(String, nullable=False)

    
    expenses = relationship("Expense", back_populates="employee")
    approvals = relationship("ApprovalStep", back_populates="approver")


class Expense(Base):
    __tablename__ = "expenses"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    amount = Column(Float, nullable=False)
    description = Column(Text, nullable=True)
    receipt_url = Column(String, nullable=True)
    status = Column(Enum(ExpenseStatus), default=ExpenseStatus.PENDING)
    created_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship("User", back_populates="expenses")
    approval_steps = relationship("ApprovalStep", back_populates="expense")


class ApprovalWorkflow(Base):
    __tablename__ = "approval_workflows"

    id = Column(Integer, primary_key=True, index=True)
    job_title = Column(String, unique=True, nullable=False)
    steps = Column(JSON, nullable=False)  # e.g. ["Team Lead", "Finance"]
    created_at = Column(DateTime, default=datetime.utcnow)


class ApprovalStep(Base):
    __tablename__ = "approval_steps"

    id = Column(Integer, primary_key=True, index=True)
    expense_id = Column(Integer, ForeignKey("expenses.id"), nullable=False)
    approver_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    step_order = Column(Integer, nullable=False)
    status = Column(Enum(ApprovalStepStatus), default=ApprovalStepStatus.PENDING)
    updated_at = Column(DateTime, default=datetime.utcnow)
    rejection_reason = Column(String, nullable=True)
    rejected_by = Column(String, nullable=True) 
    
    expense = relationship("Expense", back_populates="approval_steps")
    approver = relationship("User", back_populates="approvals")

def init_db():
    Base.metadata.create_all(bind=engine)
    print("✅ Database and tables created successfully!")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

if __name__ == "__main__":
    init_db()
