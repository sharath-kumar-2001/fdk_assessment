from fastapi import FastAPI
from db_setup import init_db
from routers import auth, expenses, approvals, workflows

app = FastAPI(title="Expense Management SaaS MVP")

# Initialize DB
init_db()

# Routers
app.include_router(auth.router)
app.include_router(expenses.router)
app.include_router(approvals.router)
app.include_router(workflows.router)

@app.get("/")
def root():
    return {"message": "Welcome to Expense Management SaaS MVP"}
