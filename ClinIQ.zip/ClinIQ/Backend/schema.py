from pydantic import BaseModel, EmailStr
from datetime import datetime

class DoctorCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    clinic_name: str | None = None

class DoctorOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    clinic_name: str | None = None
    slug: str | None = None
    created_at: datetime

    class Config:
        orm_mode = True

class AvailabilityCreate(BaseModel):
    day_of_week: str
    start_time: str
    end_time: str

class AvailabilityOut(BaseModel):
    id: int
    day_of_week: str
    start_time: str
    end_time: str
    created_at: datetime

    class Config:
        orm_mode = True

class AppointmentCreate(BaseModel):
    patient_name: str
    patient_email: EmailStr
    appointment_datetime: datetime

class AppointmentOut(BaseModel):
    id: int
    patient_name: str
    patient_email: EmailStr
    appointment_datetime: datetime
    status: str
    created_at: datetime

    class Config:
        orm_mode = True
