from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from db_setup import SessionLocal, Doctor, Appointment, Availability
from schema import DoctorCreate, DoctorOut, AvailabilityCreate, AvailabilityOut, AppointmentCreate, AppointmentOut
from passlib.hash import bcrypt
import uuid

router = APIRouter(prefix="/doctors", tags=["Doctor"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/doctor_info", response_model=DoctorOut)
def create_doctor(doctor: DoctorCreate, db: Session = Depends(get_db)):
    existing = db.query(Doctor).filter(Doctor.email == doctor.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    hashed_pw = bcrypt.hash(doctor.password)
    new_doctor = Doctor(
        name=doctor.name,
        email=doctor.email,
        password_hash=hashed_pw,
        clinic_name=doctor.clinic_name,
        slug=str(uuid.uuid4())[:8]  # simple slug for public URL
    )
    db.add(new_doctor)
    db.commit()
    db.refresh(new_doctor)
    return new_doctor

@router.get("/doctors_list", response_model=list[DoctorOut])
def get_all_doctors(db: Session = Depends(get_db)):
    return db.query(Doctor).all()

@router.post("/availability/{doctor_id}", response_model=AvailabilityOut)
def add_availability(doctor_id: int, data: AvailabilityCreate, db: Session = Depends(get_db)):
    doctor = db.query(Doctor).filter(Doctor.id == doctor_id).first()
    if not doctor:
        raise HTTPException(status_code=404, detail="Doctor not found")

    new_availability = Availability(
        doctor_id=doctor_id,
        day_of_week=data.day_of_week,
        start_time=data.start_time,
        end_time=data.end_time
    )
    db.add(new_availability)
    db.commit()
    db.refresh(new_availability)
    return new_availability

@router.get("/availability/{doctor_id}", response_model=list[AvailabilityOut])
def get_availability(doctor_id: int, db: Session = Depends(get_db)):
    return db.query(Availability).filter(Availability.doctor_id == doctor_id).all()

@router.post("/appointments/{doctor_id}", response_model=AppointmentOut)
def book_appointment(doctor_id: int, data: AppointmentCreate, db: Session = Depends(get_db)):
    doctor = db.query(Doctor).filter(Doctor.id == doctor_id).first()
    if not doctor:
        raise HTTPException(status_code=404, detail="Doctor not found")

    new_appointment = Appointment(
        doctor_id=doctor_id,
        patient_name=data.patient_name,
        patient_email=data.patient_email,
        appointment_datetime=data.appointment_datetime,
    )
    db.add(new_appointment)
    db.commit()
    db.refresh(new_appointment)
    return new_appointment

@router.patch("/appointments/{appointment_id}/{status}", response_model=AppointmentOut)
def update_status(appointment_id: int, status: str, db: Session = Depends(get_db)):
    appointment = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")

    if status not in ["booked", "completed", "no_show"]:
        raise HTTPException(status_code=400, detail="Invalid status")

    appointment.status = status
    db.commit()
    db.refresh(appointment)
    return appointment
