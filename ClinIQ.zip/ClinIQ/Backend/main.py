from fastapi import FastAPI
from routers import router

app = FastAPI(title="Doctor Clinic Backend")

app.include_router(router=router)
