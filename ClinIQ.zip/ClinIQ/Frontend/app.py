import streamlit as st
import requests
from datetime import date, time

# Base URL of your FastAPI backend
API_BASE = "http://127.0.0.1:8000/doctors"

st.set_page_config(page_title="Doctor Clinic Dashboard", page_icon="🏥", layout="wide")

st.title("🏥 One-Doctor Clinic Management System")

# Sidebar Navigation
menu = st.sidebar.radio(
    "Navigation",
    ["👨‍⚕️ Doctors", "🕒 Availability", "📅 Appointments"]
)

# --------------------------------------------------------------------
# 👨‍⚕️ Doctor Section
# --------------------------------------------------------------------
if menu == "👨‍⚕️ Doctors":
    st.header("Doctor Management")

    # 1️⃣ List all doctors
    with st.expander("View All Doctors"):
        try:
            res = requests.get(f"{API_BASE}/doctors_list")
            if res.status_code == 200:
                doctors = res.json()
                if doctors:
                    st.table(doctors)
                else:
                    st.info("No doctors found.")
            else:
                st.error("Error fetching doctor list.")
        except Exception as e:
            st.error(f"Connection error: {e}")

    # 2️⃣ Add a new doctor
    with st.expander("Add New Doctor"):
        name = st.text_input("Doctor Name")
        email = st.text_input("Email")
        clinic_name = st.text_input("Clinic Name")

        if st.button("Add Doctor"):
            payload = {
                "name": name,
                "email": email,
                "clinic_name": clinic_name
            }
            try:
                res = requests.post(f"{API_BASE}/doctor_info", json=payload)
                if res.status_code in [200, 201]:
                    st.success("✅ Doctor added successfully!")
                else:
                    st.error(f"Failed: {res.text}")
            except Exception as e:
                st.error(f"Error: {e}")

# --------------------------------------------------------------------
# 🕒 Availability Section
# --------------------------------------------------------------------
elif menu == "🕒 Availability":
    st.header("Doctor Availability")

    doctor_id = st.number_input("Enter Doctor ID", min_value=1)

    if st.button("Check Availability"):
        try:
            res = requests.get(f"{API_BASE}/availability/{doctor_id}")
            if res.status_code == 200:
                availability = res.json()
                if availability:
                    st.table(availability)
                else:
                    st.info("No availability found.")
            else:
                st.error(f"Error: {res.text}")
        except Exception as e:
            st.error(f"Error: {e}")

# --------------------------------------------------------------------
# 📅 Appointments Section
# --------------------------------------------------------------------
elif menu == "📅 Appointments":
    st.header("Appointments Management")

    tab1, tab2 = st.tabs(["🆕 Create Appointment", "🔁 Update Status"])

    # ---- Create Appointment ----
    with tab1:
        doctor_id = st.number_input("Doctor ID", min_value=1, key="doc_id")
        patient_name = st.text_input("Patient Name")
        appointment_date = st.date_input("Appointment Date", value=date.today())
        appointment_time = st.time_input("Appointment Time", value=time(10, 0))

        if st.button("Create Appointment"):
            payload = {
                "patient_name": patient_name,
                "appointment_date": str(appointment_date),
                "appointment_time": str(appointment_time)
            }
            try:
                res = requests.post(f"{API_BASE}/appointments/{doctor_id}", json=payload)
                if res.status_code in [200, 201]:
                    st.success("✅ Appointment created successfully!")
                else:
                    st.error(f"Failed: {res.text}")
            except Exception as e:
                st.error(f"Error: {e}")

    # ---- Update Appointment Status ----
    with tab2:
        appointment_id = st.number_input("Appointment ID", min_value=1)
        status = st.selectbox("Select Status", ["scheduled", "completed", "cancelled", "rescheduled"])

        if st.button("Update Status"):
            try:
                res = requests.patch(f"{API_BASE}/appointments/{appointment_id}/{status}")
                if res.status_code in [200, 201]:
                    st.success("✅ Status updated successfully!")
                else:
                    st.error(f"Failed: {res.text}")
            except Exception as e:
                st.error(f"Error: {e}")
